

Installation staps:

React Project Installation
-------------------------------

1. unzip file to any disc location
2. goto directory and open wihh VScode or any IDE
3. Hit command in terminal (`$ yarn install`)  then (`$ yarn dev`)
4. open tab:  (`http://localhost:5173/`)

Then Run JSon Local Server
-------------------------------

1. hit command "sudo npm install -g json-server" to install local json server
2. Before React project start,need to start json-server, to start that hit command (`$ json-server --watch src/db/db.json --port 3030`) that runs server to 3030 port.




